void SetBaudRate(unsigned int buadRate);

void Putch(char ch);

void Puts(const char* str);

char ReadChar();